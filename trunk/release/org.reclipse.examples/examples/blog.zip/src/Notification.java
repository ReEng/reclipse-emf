
public abstract class Notification 
{	
	public abstract void update(/*Content c*/);
}
