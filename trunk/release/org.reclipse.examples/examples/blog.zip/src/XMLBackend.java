import java.util.List;


public class XMLBackend extends Backend 
{
	public void save(Storage s) 
	{
		System.out.println("Saving to XML");
	}
}
