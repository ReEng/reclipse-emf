import java.util.List;


public class SQLBackend extends Backend 
{
	public void save(Storage s) 
	{
		System.out.println("Saving to SQL");
	}
}
