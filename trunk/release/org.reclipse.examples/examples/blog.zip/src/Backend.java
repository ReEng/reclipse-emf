import java.util.List;


public abstract class Backend 
{
	public abstract void save(Storage s);

}
